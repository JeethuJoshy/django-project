from django.db import models


class Registration(models.Model):
	name = models.CharField(max_length=200)
	email = models.CharField(max_length=200)
	phone = models.IntegerField(default=0)
	password = models.CharField(max_length=100)


	def __str__(self):
		return self.name

class Blog(models.Model):
	user = models.ForeignKey(Registration,on_delete=models.CASCADE)
	title = models.CharField(max_length=200)
	body = models.TextField(max_length=200)

	def __str__(self):
		return self.title
















# Create your models here.
