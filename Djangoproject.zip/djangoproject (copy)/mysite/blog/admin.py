from django.contrib import admin

# Register your models here.

from .models import Registration,Blog

admin.site.register(Registration)
admin.site.register(Blog)

 
